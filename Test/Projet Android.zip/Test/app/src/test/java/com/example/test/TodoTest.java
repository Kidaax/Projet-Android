package com.example.test;

import org.junit.Assert;
import org.junit.Test;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import static org.junit.Assert.*;

/**
 * Example local unit test, which will execute on the development machine (host).
 *
 * @see <a href="http://d.android.com/tools/testing">Testing documentation</a>
 */
public class TodoTest {
    @Test
    public void listTest() {
        ArrayList<String> names = new ArrayList<>();
        names.add("oui");
        for (int i = 0; i < names.size(); i++) {
            String test = names.get(i);
            System.out.println(test);
        }
    }

    @Test
    public void addTest() {
        TodoRepository repository = new TodoRepository();
        repository.add("test");
        ArrayList<Todo> allTodo = repository.getAll();

        assertEquals(1, allTodo.size());
    }

    @Test
    public void getFinishedTodosTest() {
        TodoRepository repository = new TodoRepository();
        Todo task1 = repository.add("TEST1");
        task1.setDone(true);

        Todo task2 = repository.add("TEST2");
        task2.setDone(false);

        Todo task3 = repository.add("TEST3");
        task3.setDone(true);

        Todo task4 = repository.add("TEST4");
        task4.setDone(false);

        ArrayList<Todo> finishedTodos = repository.getNotFinishedTodos();

        assertEquals(2, finishedTodos.size());

        for (int i = 0; i < finishedTodos.size(); i++) {
            Todo test = finishedTodos.get(i);
            assertFalse(test.isDone());
        }

        assertSame(task2, finishedTodos.get(0));
        assertSame(task4, finishedTodos.get(1));
    }

    @Test
    public void newIdsTest() {
        TodoRepository repository = new TodoRepository();
        Todo todo1 = repository.add("Faire la vaisselle");
        // C'est la première tache de ce repository, donc l'id doit être de "1"
        assertEquals(1, todo1.getId());

        Todo todo2 = repository.add("Faire la vaisselle");
        // C'est la deuxième tache de ce repository, donc l'id doit être de "2"
        assertEquals(2, todo2.getId());
    }

    @Test
    public void existingIdsTest() {
        // Simulation d'ajout de nouvelles taches après avoir chargées celles se trouvant dans
        // les sharedpreferences.

        TodoRepository repository = new TodoRepository();
        // Les todos provenant des sharedpreferences
        List<Todo> savedTodos = Arrays.asList(
                new Todo(10, "Faire la vaisselle"),
                new Todo(20, "Faire la vaisselle")
        );
        repository.replaceTodos(new ArrayList<>(savedTodos));

        // L'utilisateur ajoute un nouveau todo
        Todo nouveauTodo = repository.add("Faire la vaisselle");
        // C'est la deuxième tache de ce repository, donc l'id doit être de "2"
        assertEquals(21, nouveauTodo.getId());
    }

    @Test
    public void findByIdTest(){
        TodoRepository repository = new TodoRepository();
        List<Todo> savedTodos = Arrays.asList(
                new Todo(10, "Faire la vaisselle"),
                new Todo(20, "Faire la vaisselle")
        );
        repository.replaceTodos(new ArrayList<>(savedTodos));
        assertEquals(savedTodos.get(1),repository.findById(20));
    }


    @Test
    public void findMaxTest() {
        int[] ids = new int[] {
            1, 2, 45, 100
        } ;
        int maxId = findMax(ids);
        Assert.assertEquals(100, maxId);

        int newId = findNewId(ids);
        Assert.assertEquals(101, newId);
    }

    private int findNewId(int[] ids) {
        return findMax(ids) + 1;
    }

    private int findMax(int[] ids) {
        // TODO
        throw new RuntimeException();
    }
}