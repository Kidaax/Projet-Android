package com.example.test;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.FragmentManager;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.text.Editable;
import android.util.Log;
import android.view.KeyEvent;
import android.view.View;
import android.view.inputmethod.EditorInfo;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.os.Bundle;
import android.widget.Toast;

import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.gson.Gson;

import java.util.ArrayList;
import java.util.Arrays;


public class MainActivity extends AppCompatActivity implements EditNameDialogFragment.EditNameDialogListener {
    private static final String TAG = "mainActivity";
    private TodoRepository todoRepository = TodoRepository.getInstance();
    private MyAdapter adapter;
    private MyAdapter adapter2;
    private RecyclerView finishedTodoListRecyclerView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        FloatingActionButton fab = findViewById(R.id.add_todo_button);
        Button showFinishedTodo = (Button) findViewById(R.id.show_finished_todo_button);
        RecyclerView todoListRecyclerView = (RecyclerView) findViewById(R.id.todo_list_recycler_view);
        this.finishedTodoListRecyclerView = (RecyclerView) findViewById(R.id.finished_todo_list_recycler_view);

        // use a linear layout manager
        LinearLayoutManager layoutManager = new LinearLayoutManager(this);
        LinearLayoutManager layoutManager2 = new LinearLayoutManager(this);

        todoListRecyclerView.setLayoutManager(layoutManager);
        finishedTodoListRecyclerView.setLayoutManager(layoutManager2);

        adapter = new MyAdapter();
        todoListRecyclerView.setAdapter(adapter);

        adapter2 = new MyAdapter();
        finishedTodoListRecyclerView.setAdapter(adapter2);
        finishedTodoListRecyclerView.setVisibility(View.GONE);

        loadTodos();
        OnTodoClickListener onTodoClickListener = new OnTodoClickListener() {
            @Override
            public void onChecked(Todo todo, boolean isChecked) {
                todo.setDone(isChecked);
                saveTodos();
                if (isChecked) {
                    Toast.makeText(MainActivity.this, "Vous avez coché une tâche", Toast.LENGTH_SHORT).show();
                } else {
                    Toast.makeText(MainActivity.this, "Vous avez décoché une tâche", Toast.LENGTH_SHORT).show();
                }
                printTodos();
            }

            @Override
            public void onClick(Todo todo) {
                Intent intent = new Intent(MainActivity.this, EditorActivity.class);
                intent.putExtra("todoName", todo.getId());
                startActivityForResult(intent, 1);
            }
        };

        adapter.setOnTodoClickListener(onTodoClickListener);
        adapter2.setOnTodoClickListener(onTodoClickListener);
        showFinishedTodo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (finishedTodoListRecyclerView.getVisibility() == View.GONE) {
                    finishedTodoListRecyclerView.setVisibility(View.VISIBLE);
                } else {
                    finishedTodoListRecyclerView.setVisibility(View.GONE);
                }
            }
        });

        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showEditDialog();
            }
        });
    }

    public void printTodos() {
        adapter.setTodoList(todoRepository.getNotFinishedTodos());
        adapter2.setTodoList(todoRepository.getFinishedTodos());
    }

    public void saveTodos() {
        SharedPreferences sharedPref = getPreferences(Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPref.edit();
        editor.putString("todo_list", new Gson().toJson(todoRepository.getAll()));
        editor.apply();

    }

    public void loadTodos() {
        SharedPreferences sharedPref = getPreferences(Context.MODE_PRIVATE);
        String jsonTodoList = sharedPref.getString("todo_list", null);
        if (jsonTodoList != null) {
            Todo[] todos = new Gson().fromJson(jsonTodoList, Todo[].class);
            ArrayList<Todo> todoList = new ArrayList<>(Arrays.asList(todos));
            this.todoRepository.replaceTodos(todoList);
            printTodos();
        } else {
            printTodos();
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == EditorActivity.EDIT_SUCCESS) {
            saveTodos();
            printTodos();
        }
    }

    private void showEditDialog() {
        FragmentManager fm = getSupportFragmentManager();
        EditNameDialogFragment editNameDialogFragment = EditNameDialogFragment.newInstance("Ajouter tâche");
        editNameDialogFragment.show(fm, "fragment_edit_name");
    }

    public void onFinishEditDialog(String inputText) {
        this.todoRepository.add(inputText);
        Toast.makeText(MainActivity.this, "Vous avez ajouté une tâche", Toast.LENGTH_SHORT).show();
        saveTodos();
        printTodos();
    }
}