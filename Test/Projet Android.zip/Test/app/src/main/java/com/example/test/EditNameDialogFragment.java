package com.example.test;

import android.os.Bundle;
import android.util.Log;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.EditorInfo;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import androidx.annotation.Nullable;
import androidx.fragment.app.DialogFragment;

public class EditNameDialogFragment extends DialogFragment implements TextView.OnEditorActionListener {
    private EditText nameTodo;
    private static final String TAG = "editNameDialog";

    public interface EditNameDialogListener {
        void onFinishEditDialog(String inputText);
    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        // Get field from view
        nameTodo = (EditText) view.findViewById(R.id.name_todo_edit_text);
        nameTodo.setOnEditorActionListener(this);
        Button addTodo = (Button) view.findViewById(R.id.add_todo_button);
        addTodo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (nameTodo.length() != 0) {
                    addTodo();
                }
            }
        });
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        return inflater.inflate(R.layout.alert_activity, container);

    }

    public boolean onEditorAction(TextView v, int actionId, KeyEvent event) {
        if (EditorInfo.IME_ACTION_SEND == actionId) {
            if (nameTodo.length() != 0) {
                addTodo();
                return true;
            }
        }
        return false;
    }


    public static EditNameDialogFragment newInstance(String title) {
        EditNameDialogFragment frag = new EditNameDialogFragment();
        Bundle args = new Bundle();
        args.putString("titre", title);
        frag.setArguments(args);
        return frag;
    }

    public void addTodo() {
        // Return input text back to activity through the implemented listener
        EditNameDialogListener listener = (EditNameDialogListener) getActivity();
        listener.onFinishEditDialog(nameTodo.getText().toString());
        // Close the dialog and return back to the parent activity
        dismiss();
    }
}
