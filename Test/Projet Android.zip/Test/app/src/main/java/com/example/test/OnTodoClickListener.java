package com.example.test;

public interface OnTodoClickListener {

    public void onChecked(Todo todo, boolean isChecked);

    public void onClick(Todo todo);


}
