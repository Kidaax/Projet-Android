package com.example.test;

import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;



public class EditorActivity extends AppCompatActivity {
    public static final int EDIT_SUCCESS = 1;
    private static final String TAG = "editorActivity";
    private EditText editText;
    private TodoRepository todoRepository = TodoRepository.getInstance();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.editor_activity);

        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        ActionBar ab = getSupportActionBar();
        ab.setDisplayHomeAsUpEnabled(true);

        editText = (EditText) findViewById(R.id.edit_todo_edit_text);
        Button editTodo = (Button) findViewById(R.id.edit_todo_button);
        Todo todo = getTodo();
        editText.setText(todo.getName());

        editTodo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Todo todo = getTodo();
                Editable editable = editText.getText();
                String text = editable.toString();
                todo.setName(text);
                Toast.makeText(EditorActivity.this, "Tâche modifiée", Toast.LENGTH_SHORT).show();
                finish();
            }
        });
    }

    private Todo getTodo() {
        int id = intentId();
        return todoRepository.findById(id);
    }

    public int intentId() {
        Intent intent = getIntent();
        return intent.getIntExtra("todoName", 0);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_editor, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == R.id.remove_todo_button) {
            Todo todo = getTodo();
            todoRepository.remove(todo);
            Toast.makeText(EditorActivity.this, "Tâche supprimée", Toast.LENGTH_SHORT).show();
            finish();
            return true;
        }

        else {
            return super.onOptionsItemSelected(item);
        }
    }
}






